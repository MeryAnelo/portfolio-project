# portfolio-project


## RUN COMMAND
```bash
python manage.py runserver --settings portfolio.settings
```